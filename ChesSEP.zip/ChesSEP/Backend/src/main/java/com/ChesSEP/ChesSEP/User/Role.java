package com.ChesSEP.ChesSEP.User;

public enum Role {
    USER,
    ADMIN
}
